const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");
const SOS=document.querySelector("#sosbutton")

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});
document.getElementById("backHomeBtn").addEventListener("click", function() {
    // Redirect to the home page
    window.location.href = "index.html";
});
sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});

// sos.addEventListener("click", () => {
//     // Redirect to the home page
//     window.location.href = "test.php";});

// function sendSOS() {
//   $.ajax({
//       url: 'test.php', // path to your PHP file
//       method: 'POST',
//       success: function(response) {
//           alert('SOS message sent successfully!');
//       },
//       error: function(xhr, status, error) {
//           alert('Failed to send SOS message!');
//           console.error(xhr.responseText);
//       }
//   });

document.addEventListener("DOMContentLoaded", function() {
  // Get the button element
  var runPHPButton = document.getElementById("runsos");

  // Add click event listener to the button
  runPHPButton.addEventListener("click", function() {
      // Send an AJAX request to the PHP file
      var xhr = new XMLHttpRequest();
      xhr.open("GET", "C:\Users\nithi\Downloads\twilio-php-main\twilio-php-main\test.php", true); // Replace "path/to/your/phpfile.php" with the actual path
      xhr.onreadystatechange = function() {
          if (xhr.readyState === 4 && xhr.status === 200) {
              // Handle the response from the PHP file if needed
              console.log(xhr.responseText);
          }
      };
      xhr.send();
  });
});