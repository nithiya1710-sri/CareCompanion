

$(document).ready(function(){
    $('.feedback-slider').owlCarousel({
        loop: false,
        margin: 10,
        nav: true,
        items: 1,
        autoplay: true,
        navText: ["<i class = 'fas fa-arrow-left'></i>", "<i class = 'fas fa-arrow-right'></i>"]
    });

    // stop animation on resize
    let resizeTimer;
    $(window).resize(function(){
        $(document.body).addClass('resize-animation-stopper');
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            $(document.body).removeClass('resize-animation-stopper');
        }, 400);
    });

    $('.navbar-show-btn').click(function(){
        $('.navbar-box').addClass('navbar-box-show');
    });

    $('.navbar-hide-btn').click(function(){
        $('.navbar-box').removeClass("navbar-box-show");
    })
});
document.getElementById('openWindowBtn').addEventListener("click", function() {
    // Open a new window with a specified URL
    
    window.open("user-dashboard.html")
});


    document.addEventListener("DOMContentLoaded", function() {
        // Get the button element
        var runPHPButton = document.getElementById("runPHPBtn");
      
        // Add click event listener to the button
        runPHPButton.addEventListener("click", function() {
            // Send an AJAX request to the PHP file
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "C:\Users\nithi\Downloads\twilio-php-main\twilio-php-main\test.php", true); // Replace "path/to/your/phpfile.php" with the actual path
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // Handle the response from the PHP file if needed
                    console.log(xhr.responseText);
                }
            };
            xhr.send();
        });
    });